var w;
function moWin() {
    w = window.open("slides.html", "tt", "width=500,height=450,top=50,left=600");
    w.focus();
}